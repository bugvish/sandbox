var updateTimer;
var currentThingID;
var geoWatch;

function beginGatheringData(callback)
{
	if(updateTimer)
	{
		return;
	}

	var dataToShare = {};
	dweetio.set_server("");

	if(navigator.geolocation)
	{
		geoWatch = navigator.geolocation.watchPosition(function(position) {
			dataToShare.your_latitude = Number(position.coords.latitude.toFixed(6));
			dataToShare.your_longitude = Number(position.coords.longitude.toFixed(6));
		});
	}

	function updateSharedData()
	{
		if(currentThingID)
		{
			dweetio.dweet_for(currentThingID, dataToShare, function(err, content)
			{
				callback(content);
			});
		}
		else
		{
			dweetio.dweet(dataToShare, function(err, content){
				currentThingID = content.thing;
				callback(content);
			});
		}
	}

	$(document).bind("mousemove", function(event)
	{
		dataToShare.mouse_x = event.pageX;
		dataToShare.mouse_y = event.pageY;
	});

	if(gyro.hasFeature('deviceorientation'))
	{
        gyro.startTracking(function(event) {
            dataToShare.tilt_x = Math.round(event.beta);
            dataToShare.tilt_y = Math.round(event.gamma);
            dataToShare.tilt_z = Math.round(event.alpha);
        });
	}

	updateSharedData();
	updateTimer = setInterval(updateSharedData, 1000);
}

function stopGatheringData()
{
	if(updateTimer)
	{
		clearInterval(updateTimer);
		updateTimer = undefined;
	}

	if(geoWatch)
	{
		navigator.geolocation.clearWatch(geoWatch);
		geoWatch = null;
	}

    gyro.stopTracking();

	$(document).unbind("mousemove");
}